﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; 

public class PruebaDeMovimiento : MonoBehaviour
{
    public GameObject Referencia;

    public float Speed;
    public float MaxSpeed; 

    private Rigidbody rb; 

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void FixedUpdate ()
    {
        float MovHorizontal = Input.GetAxis("Horizontal");
        float MovVertical = Input.GetAxis("Vertical"); 

        if (rb.velocity.magnitude > MaxSpeed)
        {
            rb.velocity = rb.velocity.normalized * MaxSpeed; 
        }

        rb.AddForce(MovHorizontal * Referencia.transform.right * Speed);
        rb.AddForce(MovVertical * Referencia.transform.forward * Speed);
    }
    //else... si presionas este boton, el animator coge x animación. 
    // W,A,S,D 
    //Shift presionado te agachas(Se esconde)
    //Control Corre


    void OnCollisionEnter(Collision otherObj)
    {
        if (otherObj.gameObject.tag == "Bullie")
        {
            Destroy(gameObject);
            SceneManager.LoadScene("GameOver");
        }
    }





}

