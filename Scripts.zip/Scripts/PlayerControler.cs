﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
//using UnityEngine.Animator; 
using UnityEngine;

public class PlayerControler : MonoBehaviour
{
    public GameObject Player;
    public GameObject Referencia;

    private Rigidbody rb;

    [Range(0, 10)] public float Speed;


    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }


    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        if (horizontal != 0.0f || vertical != 0.0f)
        {
            Vector3 dir = transform.forward * vertical + transform.right * horizontal;
            rb.MovePosition(transform.position + dir * Speed * Time.deltaTime);

        }
    }

    // si muere hace cambio de escena a Game over
    //Si gana hace cambio de escena a Winner
}
