﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConCamera : MonoBehaviour
{
    public GameObject Player;
    public GameObject Referencia;
    private Vector3 Distancia; 

    void Start()
    {
        Distancia = transform.position - Player.transform.position;
    }

  
    void LateUpdate()
    {
        Distancia = Quaternion.AngleAxis(Input.GetAxis("Mouse X") * 2, Vector3.up) * Distancia; 

        transform.position = Player.transform.position + Distancia;
        transform.LookAt(Player.transform.position);

        Vector3 Rotacion = new Vector3(0, transform.eulerAngles.y, 0);
        Referencia.transform.eulerAngles = Rotacion; 

    }
}
