﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Perseguir : StateMachineBehaviour //emplea la máquina de estados en vez de monobehaviour
{
    private NavMeshAgent Agent; //quién se mueve por el navmesh? interactúa con el component
    private Transform target;

    public override void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) //estado de inicio del animator
    {
        Agent = animator.GetComponent<NavMeshAgent>(); //el agente se moverá por el navmesh
        Color Color = new Color(1.0f, 0.0f, 0.0f, 1.0f); //cambio de color en el caso
        Agent.GetComponent<Renderer>().material.color = Color; //llama al renderer para efectuar el cambio de color  
    }

    public override void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex) //en vez de void update, usamos esta función
    {
        RaycastHit hit;
        if ((Physics.Raycast(animator.transform.position, animator.transform.forward, out hit, 10)) && (hit.collider.tag == "Bullie")) //en el caso de estar en una distancia considerable,
        {
            target = hit.collider.transform;
            Agent.destination = hit.collider.transform.position; //el agente se moverá adonde quiera que esté el AGENTE con su etiqueta.
        }
        else
        {
            Agent.destination = target.position;
        }
    }
}


