﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI; 

public class Bully : MonoBehaviour
{
    public NavMeshAgent Bullie;
    public Transform Target;
    public GameObject[] Waypoints;

    bool Localizado = false; 

    public float DistanciaTarget = 5f; 

    int Desplazarse = 1;
  

    void Start()
    {
        Bullie = GetComponent<NavMeshAgent>();
    }

    void Update()
    {
        //Esto se ejecuta con normalidad junto al animator de patrulla.
        if (Bullie.remainingDistance < 1 && !Localizado)
        {
            recorrido();
        }

        //Animación de localizar al jugador y perseguir.

        //Lanza rayo para localizar al jugador en todo momento y si está a X distancia se detecta y el booleano se vuelve verdadero
        RaycastHit Hit = new RaycastHit();

        Debug.DrawRay(transform.position, (Target.position - transform.position), Color.yellow);

        if (Physics.Raycast(transform.position, (Target.position - transform.position).normalized, out Hit, DistanciaTarget, 1 << 8))
        {
            Localizado = true;

            Debug.Log("Did Hit");
        }

        if (Localizado)
        {
            Bullie.SetDestination(Target.position);
        }

        else
        {
            Localizado = false;
        }

    }

     void recorrido()
     {
        if (Waypoints.Length == null)
            return;

        Bullie.destination = Waypoints[Desplazarse].transform.position;
        Desplazarse = (Desplazarse + 1) % Waypoints.Length;
     }
}
