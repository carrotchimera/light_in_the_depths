﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI; 

public class IADirector : MonoBehaviour
{
    public GameObject[] Waypoints; //lo mismo!!
    public GameObject[] Central;

    private Vector3[][] rutas; //array de arrays de vector3

    private bool[] RutaOcu;

    void Start()
    {
        Waypoints = GameObject.FindGameObjectsWithTag("Puntos"); //buscamos aquellos puntos, asimismo, para el novato y su patrulla
        Central = GameObject.FindGameObjectsWithTag("Centro"); //para llegar al centro del escenario, establecido con su propia etiqueta
        RutaOcu = new bool[Central.Length];

        rutas = new Vector3[Central.Length][];
        List<Vector3> ruta;
        //aquí empezamos a calcular las zonas por donde nos moveremos
        for (int i = 0; i < Central.Length; i++)
        {
            ruta = new List<Vector3>();
            foreach (GameObject puntitos in Waypoints)
            {
                if (Vector3.Distance(puntitos.transform.position, Central[i].transform.position) < 10)
                {
                    ruta.Add(puntitos.transform.position);
                }
            }
            rutas[i] = ruta.ToArray();
        }
    }

    public Vector3[] DameWaypoints(Vector3 posicion) //buscamos la posición del elemento que ha sido otorgado mediante el director de IA con Vector3. este punto es dado del array DameTorre que depende del director.
    {
        int mascercano = 0; //no hay nada que nos quede cerquita :(
        float distancia = Mathf.Infinity; //distancia del ojeto que nos queda mas cerca hasta ahora, como no hay nada aun, es distancia infinitA!!
        for (int i = 0; i < Central.Length; i++) //i++ es para que haya un incremento de uno en uno
        {
            float nuevaDistancia = Vector3.Distance(posicion, Central[i].transform.position);
            if ((nuevaDistancia < distancia) && RutaOcu[i])//! establece que NO es eso!! por lo tanto es falso ??? negamos que está ocupada, por lo que está libre
            {
                distancia = nuevaDistancia;
                mascercano = i; //rellenamos la posición de manera que ahora tenems un integer dentro del array
            }
        }

        RutaOcu[mascercano] = true;
        return rutas[mascercano];
    }

}
