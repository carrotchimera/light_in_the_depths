﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Acompañantes :StateMachineBehaviour

{
    float giro = 30.0f; //permite la rotación del agente. elemento que es llamado más adelante

    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        animator.gameObject.transform.Rotate(Vector3.up * giro * Time.deltaTime); //rotación sobre sí mismo, en el tiempo determinado por el motor,

        RaycastHit hit;
        if ((Physics.Raycast(animator.transform.position, animator.transform.forward, out hit, 10)) && (hit.collider.tag == "Bullie")) //en el caso de estar en una distancia considerable,
        {
            animator.SetBool("Pursue", true); //se pasa al siguiente estado de la máquina de estados
        }
    }
}



